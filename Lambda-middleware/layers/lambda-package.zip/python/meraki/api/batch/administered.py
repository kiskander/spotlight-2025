import urllib


class ActionBatchAdministered(object):
    def __init__(self):
        super(ActionBatchAdministered, self).__init__()
        
