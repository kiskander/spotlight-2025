import urllib


class ActionBatchWirelessController(object):
    def __init__(self):
        super(ActionBatchWirelessController, self).__init__()
        
